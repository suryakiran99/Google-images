export class Keyword{
    ID:number;
    Word:string;
    constructor(id,word){
        this.ID=id;
        this.Word = word;
    }
}